#include <gtk/gtk.h>


void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button16_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button16chercher_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_def_aff_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button_capteur_def_clicked          (GtkWidget     *objet,
                                        gpointer         user_data);

void
on_buttonhome_exit_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonhome_acceuil_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button15_retour_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonaff_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_rmchercher_btn_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmaffadd_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmaffmod_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmaffsupp_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmaffaff_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmaffquit_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmaddadd_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmaddretour_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmmodmod_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_rmmodretour_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
